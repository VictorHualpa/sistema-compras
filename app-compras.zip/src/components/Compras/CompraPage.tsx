// CompraPage.tsx
import { useEffect, useState } from "react";
import {
  Container,
  Typography,
  Box,
  Dialog,
  DialogTitle,
  DialogContent,
  Grid,
  Button,
} from "@mui/material";
import {
  obtenerCompras,
  crearCompra,
  obtenerProductos,
} from "./compra.api";
import { Compra, CompraDetalle, Producto } from "./compra.types";
import CompraForm from "./CompraForm";
import CompraTabla from "./CompraTabla";

const compraInicial: Compra = {
  proveedor: "",
  fecha: "",
  estado: "Pendiente",
  usuario_crea: "",
  fch_crea: null,
  detalles: [],
};

export default function CompraPage() {
  const [compras, setCompras] = useState<Compra[]>([]);
  const [productos, setProductos] = useState<Producto[]>([]);
  const [formulario, setFormulario] = useState<Compra>({ ...compraInicial });
  const [modalAbierto, setModalAbierto] = useState(false);

  const cargarDatos = async () => {
    const comprasData = await obtenerCompras();
    const productosData = await obtenerProductos();
    setCompras(comprasData);
    setProductos(productosData);
  };

  useEffect(() => {
    cargarDatos();
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormulario({ ...formulario, [e.target.name]: e.target.value });
  };

  const onDetalleChange = (index: number, field: string, value: any) => {
    const nuevosDetalles = [...formulario.detalles];
    nuevosDetalles[index] = { ...nuevosDetalles[index], [field]: value };
    setFormulario({ ...formulario, detalles: nuevosDetalles });
  };

  const agregarDetalle = () => {
    setFormulario({
      ...formulario,
      detalles: [
        ...formulario.detalles,
        { producto_id: 0, cantidad: 1, precio_unitario: 0 },
      ],
    });
  };

  const eliminarDetalle = (index: number) => {
    const nuevos = formulario.detalles.filter((_, i) => i !== index);
    setFormulario({ ...formulario, detalles: nuevos });
  };

  const handleGuardar = async () => {
    await crearCompra(formulario);
    setFormulario({ ...compraInicial });
    setModalAbierto(false);
    cargarDatos();
  };

  return (
    <Container maxWidth="xl">
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Typography variant="h5">Compras</Typography>
        <Button variant="contained" onClick={() => setModalAbierto(true)}>
          Nueva compra
        </Button>
      </Box>

      <CompraTabla compras={compras} />

      <Dialog open={modalAbierto} onClose={() => setModalAbierto(false)} fullWidth maxWidth="md">
        <DialogTitle>Nueva Compra</DialogTitle>
        <DialogContent>
          <Box mt={1}>
            <Grid container spacing={2}>
              <CompraForm
                values={formulario}
                productos={productos}
                onChange={handleChange}
                onDetalleChange={onDetalleChange}
                agregarDetalle={agregarDetalle}
                eliminarDetalle={eliminarDetalle}
              />
            </Grid>
            <Box mt={3} textAlign="right">
              <Button variant="contained" onClick={handleGuardar}>
                Guardar
              </Button>
            </Box>
          </Box>
        </DialogContent>
      </Dialog>
    </Container>
  );
}

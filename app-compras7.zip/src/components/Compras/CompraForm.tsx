import {
  Box,
  Button,
  Grid,
  TextField,
  Typography,
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  Paper,
} from "@mui/material";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import { Dayjs } from "dayjs";
import { useState } from "react";
import { createCompra } from "../../api/compraApi";
import CompraDetalleRow from "./CompraDetalleRow";
import { CompraCabecera, CompraDetalle } from "./compra.types";
import { compraSchema } from "./compra.schema";
import useSnackbar from "../../hooks/useSnackbar";

interface Props {
  onCompraRegistrada: () => void;
}

export default function CompraForm({ onCompraRegistrada }: Props) {
  const { showSnackbar } = useSnackbar();

  const [cabecera, setCabecera] = useState<CompraCabecera>({
    cod_proveedor: "",
    num_documento: "",
    fec_emision: "",
    fec_entrega: "",
  });

  const [fecEmision, setFecEmision] = useState<Dayjs | null>(null);
  const [fecEntrega, setFecEntrega] = useState<Dayjs | null>(null);

  const [detalle, setDetalle] = useState<CompraDetalle[]>([
    {
      cod_producto: "",
      descripcion_producto: "",
      cantidad: 1,
      precio_unitario: 0,
    },
  ]);

  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleChangeCabecera = (e: React.ChangeEvent<HTMLInputElement>) => {
    setCabecera({ ...cabecera, [e.target.name]: e.target.value });
  };

  const handleChangeDetalle = (
    index: number,
    field: keyof CompraDetalle,
    value: string | number
  ) => {
    const newDetalle = [...detalle];
    if (field === "cantidad" || field === "precio_unitario") {
      newDetalle[index][field] = Number(value);
    } else {
      newDetalle[index][field] = value as string;
    }
    setDetalle(newDetalle);
  };

  const handleAddDetalle = () => {
    setDetalle([
      ...detalle,
      {
        cod_producto: "",
        descripcion_producto: "",
        cantidad: 1,
        precio_unitario: 0,
      },
    ]);
  };

  const handleRemoveDetalle = (index: number) => {
    setDetalle(detalle.filter((_, i) => i !== index));
  };

  const getUsuarioFromToken = (): string | null => {
    const token = localStorage.getItem("token");
    if (!token) return null;
    try {
      const payload = JSON.parse(atob(token.split(".")[1]));
      return payload?.usuario || null;
    } catch (e) {
      console.error("Error al decodificar token:", e);
      return null;
    }
  };

  const handleSubmit = async () => {
    const fec_emision = fecEmision?.format("YYYY-MM-DD") || "";
    const fec_entrega = fecEntrega?.format("YYYY-MM-DD") || "";

    const usuario = getUsuarioFromToken();
    if (!usuario) {
      showSnackbar("Token inválido o no encontrado", "error");
      return;
    }

    const compraCompleta = {
      cabecera: {
        ...cabecera,
        fec_emision,
        fec_entrega,
      },
      detalle,
    };

    const result = compraSchema.safeParse(compraCompleta);

    if (!result.success) {
      const fieldErrors: Record<string, string> = {};
      result.error.errors.forEach((e) => {
        const path = e.path.join(".");
        fieldErrors[path] = e.message;
      });
      setErrors(fieldErrors);
      showSnackbar("Corrige los errores del formulario", "error");
      return;
    }

    try {
      const compra = {
        ...compraCompleta.cabecera,
        usuario_crea: usuario,
        detalles: detalle,
      };

      console.log("🟡 Enviando a backend:", JSON.stringify(compra, null, 2));

      await createCompra(compra);
      showSnackbar("Compra registrada con éxito", "success");
      onCompraRegistrada();
    } catch (error) {
      console.error("Error al registrar la compra:", error);
      showSnackbar("Error al registrar la compra", "error");
    }
  };

  return (
    <Paper sx={{ p: 3, mb: 4 }}>
      <Typography variant="h6" gutterBottom>
        Registrar Compra
      </Typography>

      <Grid container spacing={2}>
        <Grid xs={12} md={3}>
          <TextField
            label="Proveedor"
            name="cod_proveedor"
            value={cabecera.cod_proveedor}
            onChange={handleChangeCabecera}
            error={!!errors["cabecera.cod_proveedor"]}
            helperText={errors["cabecera.cod_proveedor"]}
            fullWidth
            size="small"
          />
        </Grid>
        <Grid xs={12} md={3}>
          <TextField
            label="N° Documento"
            name="num_documento"
            value={cabecera.num_documento}
            onChange={handleChangeCabecera}
            error={!!errors["cabecera.num_documento"]}
            helperText={errors["cabecera.num_documento"]}
            fullWidth
            size="small"
          />
        </Grid>
        <Grid xs={12} md={3}>
          <DatePicker
            label="Fecha Emisión"
            value={fecEmision}
            onChange={(newValue) => setFecEmision(newValue)}
          />
        </Grid>
        <Grid xs={12} md={3}>
          <DatePicker
            label="Fecha Entrega"
            value={fecEntrega}
            onChange={(newValue) => setFecEntrega(newValue)}
          />
        </Grid>
      </Grid>

      <Box mt={4}>
        <Typography variant="subtitle1">Detalle de Productos</Typography>
        <Table size="small">
          <TableHead>
            <TableRow>
              <TableCell>Código</TableCell>
              <TableCell>Descripción</TableCell>
              <TableCell>Cantidad</TableCell>
              <TableCell>Precio Unitario</TableCell>
              <TableCell>Acción</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {detalle.map((item, index) => (
              <CompraDetalleRow
                key={index}
                item={item}
                index={index}
                onChange={handleChangeDetalle}
                onRemove={handleRemoveDetalle}
              />
            ))}
          </TableBody>
        </Table>
        <Button onClick={handleAddDetalle} sx={{ mt: 2 }}>
          Agregar Producto
        </Button>
      </Box>

      <Box mt={4} textAlign="right">
        <Button variant="contained" onClick={handleSubmit}>
          Guardar Compra
        </Button>
      </Box>
    </Paper>
  );
}

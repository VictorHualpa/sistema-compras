import { Request, Response } from 'express';
import * as CompraModel from '../models/compraModel';
import { pool } from '../db';

export const listar = async (req: Request, res: Response) => {
    const compras = await CompraModel.obtenerCompras();
    res.json(compras);
};

export const obtener = async (req: Request, res: Response): Promise<void> => {
    const { id } = req.params;
    const result = await pool.query("SELECT * FROM compras.cabecera_compra WHERE id = $1", [id]);
    const compra = result.rows[0];
  
    if (!compra) {
      res.status(404).json({ mensaje: 'Compra no encontrada' }); // ✅ sin return
      return; // Solo salimos de la función
    }
  
    res.json(compra);
  };
  


export const crear = async (req: Request, res: Response) => {
    try {
        const usuario = (req as any).usuario?.id || 'anon';
        const nuevaCompra = await CompraModel.crearCompra({
            ...req.body,
            cabecera: {
                ...req.body.cabecera,
                cod_usuario_c: usuario,
            }
        });
        res.status(201).json(nuevaCompra);
    } catch (err) {
        res.status(500).json({ mensaje: 'Error al registrar la compra', error: err });
    }
};

export const eliminar = async (req: Request, res: Response) => {
    const id = parseInt(req.params.id);
    await CompraModel.eliminarCompra(id);
    res.status(204).send();
};
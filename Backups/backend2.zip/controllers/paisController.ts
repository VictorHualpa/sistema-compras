import { Request, Response } from "express";
import * as model from "../models/paisModel";

export const listar = async (_req: Request, res: Response) => {
  const data = await model.obtenerPaises();
  res.json(data);
};

export const obtener = async (req: Request, res: Response) => {
  const data = await model.obtenerPais(req.params.id);
  res.json(data);
};

export const crear = async (req: Request, res: Response) => {
  try {
    const data = await model.crearPais(req.body);
    res.json(data);
  } catch (error) {
    res.status(500).json({ error: "Error al crear país" });
  }
};

export const actualizar = async (req: Request, res: Response) => {
  try {
    const data = await model.actualizarPais(req.params.id, req.body);
    res.json(data);
  } catch (error) {
    res.status(500).json({ error: "Error al actualizar país" });
  }
};

export const eliminar = async (req: Request, res: Response) => {
  try {
    await model.eliminarPais(req.params.id);
    res.json({ mensaje: "País eliminado" });
  } catch (error) {
    res.status(500).json({ error: "Error al eliminar país" });
  }
};
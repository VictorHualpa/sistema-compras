import { pool } from '../db';

export const obtenerPaises = async () => {
  const result = await pool.query("SELECT * FROM pais ORDER BY cod_pais");
  return result.rows;
};

export const obtenerPais = async (id: string) => {
  const result = await pool.query("SELECT * FROM pais WHERE cod_pais = $1", [id]);
  return result.rows[0];
};

export const crearPais = async (data: any) => {
  const {
    cod_pais,
    nom_pais,
    flg_replica,
    cod_usuario_c,
    fch_crea,
    cod_usuario_m,
    fch_mod,
    nom_pais_en_ingles,
    flg_estado,
  } = data;
  const result = await pool.query(
    `INSERT INTO pais (cod_pais, nom_pais, flg_replica, cod_usuario_c, fch_crea, cod_usuario_m, fch_mod, nom_pais_en_ingles, flg_estado)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,
    [cod_pais, nom_pais, flg_replica, cod_usuario_c, fch_crea, cod_usuario_m, fch_mod, nom_pais_en_ingles, flg_estado]
  );
  return result.rows[0];
};

export const actualizarPais = async (id: string, data: any) => {
  const {
    nom_pais,
    flg_replica,
    cod_usuario_c,
    fch_crea,
    cod_usuario_m,
    fch_mod,
    nom_pais_en_ingles,
    flg_estado,
  } = data;
  const result = await pool.query(
    `UPDATE pais SET nom_pais=$1, flg_replica=$2, cod_usuario_c=$3, fch_crea=$4, cod_usuario_m=$5, fch_mod=$6,
     nom_pais_en_ingles=$7, flg_estado=$8 WHERE cod_pais=$9 RETURNING *`,
    [nom_pais, flg_replica, cod_usuario_c, fch_crea, cod_usuario_m, fch_mod, nom_pais_en_ingles, flg_estado, id]
  );
  return result.rows[0];
};

export const eliminarPais = async (id: string) => {
  await pool.query("DELETE FROM pais WHERE cod_pais = $1", [id]);
};
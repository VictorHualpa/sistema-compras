import { Router } from "express";
import * as controller from "../controllers/paisController";
import { verificarToken } from "../middleware/auth";

const router = Router();

router.get("/", verificarToken, controller.listar);
router.get("/:id", verificarToken, controller.obtener);
router.post("/", verificarToken, controller.crear);
router.put("/:id", verificarToken, controller.actualizar);
router.delete("/:id", verificarToken, controller.eliminar);

export default router;

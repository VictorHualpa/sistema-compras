import { Router } from 'express';
import * as compraController from '../controllers/compraController';
import { verificarToken } from '../middleware/auth';

const router = Router();

router.get('/', verificarToken, compraController.listar);
router.get('/:id', verificarToken, compraController.obtener);
router.post('/', verificarToken, compraController.crear);
router.delete('/:id', verificarToken, compraController.eliminar);

export default router;
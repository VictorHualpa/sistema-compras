export interface Familia {
    cod_familia: string;
    dsc_familia: string;
    cst_unit_prom: string;
    flg_sis_fam: string;
    corr_subfam: string;
    cst_unit_cif: string;
    flg_replica: string;
    cod_usuario_c: string;
    fch_crea: string | null;
  }
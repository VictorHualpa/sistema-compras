// CompraForm.tsx
import {
  Grid,
  TextField,
  IconButton,
  Typography,
  Box,
  Button,
  MenuItem,
} from "@mui/material";
import DeleteIcon from "@mui/icons-material/Delete";
import AddCircleIcon from "@mui/icons-material/AddCircle";
import { Compra, CompraDetalle, Producto } from "./compra.types";

interface Props {
  values: Compra;
  productos: Producto[];
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onDetalleChange: (index: number, field: string, value: any) => void;
  agregarDetalle: () => void;
  eliminarDetalle: (index: number) => void;
}

export default function CompraForm({
  values,
  productos,
  onChange,
  onDetalleChange,
  agregarDetalle,
  eliminarDetalle,
}: Props) {
  return (
    <>
      <Grid item xs={12} sm={6}>
        <TextField
          label="Proveedor"
          name="proveedor"
          value={values.proveedor || ""}
          onChange={onChange}
          fullWidth
        />
      </Grid>
      <Grid item xs={12} sm={6}>
        <TextField
          label="Fecha"
          type="date"
          name="fecha"
          InputLabelProps={{ shrink: true }}
          value={values.fecha || ""}
          onChange={onChange}
          fullWidth
        />
      </Grid>

      <Grid item xs={12}>
        <Typography variant="subtitle1" mt={2} mb={1}>
          Detalle de Productos
        </Typography>

        {values.detalles.map((detalle, index) => (
          <Box key={index} display="flex" gap={1} mb={1}>
            <TextField
              select
              label="Producto"
              value={detalle.producto_id}
              onChange={(e) =>
                onDetalleChange(index, "producto_id", parseInt(e.target.value))
              }
              fullWidth
            >
              {productos.map((p) => (
                <MenuItem key={p.id} value={p.id}>
                  {p.nombre}
                </MenuItem>
              ))}
            </TextField>

            <TextField
              label="Cantidad"
              type="number"
              value={detalle.cantidad}
              onChange={(e) =>
                onDetalleChange(index, "cantidad", parseFloat(e.target.value))
              }
              fullWidth
            />
            <TextField
              label="Precio Unit."
              type="number"
              value={detalle.precio_unitario}
              onChange={(e) =>
                onDetalleChange(index, "precio_unitario", parseFloat(e.target.value))
              }
              fullWidth
            />
            <TextField
              label="Subtotal"
              value={(detalle.cantidad * detalle.precio_unitario).toFixed(2)}
              disabled
              fullWidth
            />
            <IconButton color="error" onClick={() => eliminarDetalle(index)}>
              <DeleteIcon />
            </IconButton>
          </Box>
        ))}

        <Button
          variant="outlined"
          startIcon={<AddCircleIcon />}
          onClick={agregarDetalle}
        >
          Agregar producto
        </Button>
      </Grid>
    </>
  );
}

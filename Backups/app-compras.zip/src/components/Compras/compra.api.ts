// compra.api.ts
import { Compra } from "./compra.types";

const API = "http://localhost:5000/api";

export const obtenerCompras = async () => {
  const token = localStorage.getItem("token");
  const res = await fetch(`${API}/compras`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  return res.json();
};

export const crearCompra = async (compra: Compra) => {
  const token = localStorage.getItem("token");
  const res = await fetch(`${API}/compras`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify(compra),
  });
  return res.json();
};

export const obtenerProductos = async () => {
  const token = localStorage.getItem("token");
  const res = await fetch(`${API}/productos`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  return res.json();
};

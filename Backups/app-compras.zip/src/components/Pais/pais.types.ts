export interface Pais {
    cod_pais: string;
    nom_pais: string;
    flg_replica: string;
    cod_usuario_c: string;
    fch_crea: string | null;
    cod_usuario_m: string;
    fch_mod: string | null;
    nom_pais_en_ingles: string;
    flg_estado: string;
  }
  
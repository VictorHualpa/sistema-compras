export interface Marca {
    cod_familia: string;
    cod_marca: string;
    dsc_marca: string;
    flg_replica: string;
    cod_usuario_c: string;
    fch_crea: string | null;
    cod_usuario_m: string;
    fch_mod: string | null;
  }
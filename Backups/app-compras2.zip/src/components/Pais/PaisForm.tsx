import { Grid, TextField } from "@mui/material";
import { Pais } from "./pais.types";

interface Props {
  values: Pais;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  editando: boolean;
}

export default function PaisForm({ values, onChange, editando }: Props) {
  return (
    <>
      <Grid item xs={12} sm={4}>
        <TextField
          name="cod_pais"
          label="Código"
          value={values.cod_pais}
          onChange={onChange}
          fullWidth
          required
          disabled={editando}
        />
      </Grid>
      <Grid item xs={12} sm={4}>
        <TextField
          name="nom_pais"
          label="Nombre del país"
          value={values.nom_pais}
          onChange={onChange}
          fullWidth
          required
        />
      </Grid>
      <Grid item xs={12} sm={4}>
        <TextField
          name="nom_pais_en_ingles"
          label="Nombre en inglés"
          value={values.nom_pais_en_ingles}
          onChange={onChange}
          fullWidth
        />
      </Grid>
      <Grid item xs={6} sm={4}>
        <TextField
          name="flg_replica"
          label="Replica"
          value={values.flg_replica}
          onChange={onChange}
          fullWidth
        />
      </Grid>
      <Grid item xs={6} sm={4}>
        <TextField
          name="cod_usuario_c"
          label="Usuario creador"
          value={values.cod_usuario_c}
          onChange={onChange}
          fullWidth
        />
      </Grid>
      <Grid item xs={6} sm={4}>
        <TextField
          name="fch_crea"
          label="Fecha creación"
          type="date"
          value={values.fch_crea || ""}
          onChange={onChange}
          fullWidth
          InputLabelProps={{ shrink: true }}
        />
      </Grid>
      <Grid item xs={6} sm={4}>
        <TextField
          name="cod_usuario_m"
          label="Usuario modificador"
          value={values.cod_usuario_m}
          onChange={onChange}
          fullWidth
        />
      </Grid>
      <Grid item xs={6} sm={4}>
        <TextField
          name="fch_mod"
          label="Fecha modificación"
          type="date"
          value={values.fch_mod || ""}
          onChange={onChange}
          fullWidth
          InputLabelProps={{ shrink: true }}
        />
      </Grid>
      <Grid item xs={6} sm={4}>
        <TextField
          name="flg_estado"
          label="Estado"
          value={values.flg_estado}
          onChange={onChange}
          fullWidth
        />
      </Grid>
    </>
  );
}
// components/pais/PaisTabla.tsx
import { Pais } from "./pais.types";
import { getPaisColumns } from "./pais.columns";
import CustomDataGrid from "../comunes/CustomDataGrid";

interface Props {
  paises: Pais[];
  onEditar: (pais: Pais) => void;
  onEliminar: (id: string) => void;
}

export default function PaisTabla({ paises, onEditar, onEliminar }: Props) {
  const columnas = getPaisColumns({ onEditar, onEliminar });

  return (
    <CustomDataGrid
      rows={paises}
      columns={columnas}
      getRowId={(row) => row.cod_pais}
    />
  );
}

// PaisPage.tsx
import { useEffect, useState } from "react";
import {
  Container,
  Typography,
  Box,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  Grid,
  useTheme,
  useMediaQuery,
} from "@mui/material";
import DeleteIcon from "@mui/icons-material/Delete";
import AddCircleOutlineIcon from "@mui/icons-material/AddCircleOutline";

import { Pais } from "./pais.types";
import {
  obtenerPaises,
  crearPais,
  actualizarPais,
  eliminarPais,
} from "../../api/paisApi";
import PaisForm from "./PaisForm";
import PaisTabla from "./PaisTabla";
import ConfirmDialog from "../comunes/ConfirmDialog";
import CustomSnackbar from "../comunes/CustomSnackbar";
import useSnackbar from "../../hooks/useSnackbar";
import FormContainer from "../comunes/FormContainer";

const paisInicial: Pais = {
  cod_pais: "",
  nom_pais: "",
  flg_replica: "",
  cod_usuario_c: "",
  fch_crea: null,
  cod_usuario_m: "",
  fch_mod: null,
  nom_pais_en_ingles: "",
  flg_estado: "",
};

export default function PaisPage() {
  const [paises, setPaises] = useState<Pais[]>([]);
  const [formulario, setFormulario] = useState<Pais>({ ...paisInicial });
  const [editando, setEditando] = useState(false);
  const [modalAbierto, setModalAbierto] = useState(false);
  const [confirmarEliminar, setConfirmarEliminar] = useState(false);
  const [paisAEliminar, setPaisAEliminar] = useState<string | null>(null);

  const theme = useTheme();
  const esMovil = useMediaQuery(theme.breakpoints.down("sm"));

  const {
    open,
    message,
    severity,
    showSnackbar,
    closeSnackbar,
  } = useSnackbar();

  const cargarPaises = async () => {
    const data = await obtenerPaises();
    setPaises(data);
  };

  useEffect(() => {
    cargarPaises();
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormulario({ ...formulario, [e.target.name]: e.target.value });
  };

  const limpiarFechas = (datos: Pais): Pais => {
    return {
      ...datos,
      fch_crea: datos.fch_crea === "" ? null : datos.fch_crea,
      fch_mod: datos.fch_mod === "" ? null : datos.fch_mod,
    };
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const datosLimpios = limpiarFechas(formulario);
    try {
      if (editando) {
        await actualizarPais(formulario.cod_pais, datosLimpios);
        showSnackbar("Registro actualizado correctamente", "success");
      } else {
        await crearPais(datosLimpios);
        showSnackbar("País creado exitosamente", "success");
      }
      setFormulario({ ...paisInicial });
      setEditando(false);
      setModalAbierto(false);
      cargarPaises();
    } catch (error) {
      showSnackbar("Ocurrió un error al guardar los datos", "error");
    }
  };

  const handleEditar = (pais: Pais) => {
    setFormulario({
      ...pais,
      fch_crea: pais.fch_crea ? pais.fch_crea.split("T")[0] : "",
      fch_mod: pais.fch_mod ? pais.fch_mod.split("T")[0] : "",
    });
    setEditando(true);
    setModalAbierto(true);
  };

  const confirmarEliminarPais = (id: string) => {
    setPaisAEliminar(id);
    setConfirmarEliminar(true);
  };

  const handleEliminar = async () => {
    if (paisAEliminar) {
      await eliminarPais(paisAEliminar);
      showSnackbar("Registro eliminado correctamente", "success");
      cargarPaises();
    }
    setConfirmarEliminar(false);
    setPaisAEliminar(null);
  };

  const abrirModalNuevo = () => {
    setFormulario({ ...paisInicial });
    setEditando(false);
    setModalAbierto(true);
  };

  return (
    <Container maxWidth="xl" sx={{ py: 4 }}>
      <Box
        display="flex"
        justifyContent="space-between"
        alignItems={esMovil ? "start" : "center"}
        flexDirection={esMovil ? "column" : "row"}
        gap={2}
        mb={3}
      >
        <Typography variant="h4" fontWeight="bold">
          Gestión de Países
        </Typography>
        <Button
          variant="contained"
          onClick={abrirModalNuevo}
          startIcon={<AddCircleOutlineIcon />}
        >
          Crear nuevo país
        </Button>
      </Box>

      <PaisTabla
        paises={paises}
        onEditar={handleEditar}
        onEliminar={confirmarEliminarPais}
      />

      <Dialog
        open={modalAbierto}
        onClose={() => setModalAbierto(false)}
        maxWidth="md"
        fullWidth
        scroll="paper"
      >
        <DialogTitle>{editando ? "Editar País" : "Nuevo País"}</DialogTitle>
        <DialogContent dividers sx={{ maxHeight: "80vh" }}>
          <FormContainer>
            <Grid
              container
              spacing={2}
              component="form"
              method="post"
              onSubmit={handleSubmit}
            >
              <PaisForm
                values={formulario}
                onChange={handleChange}
                editando={editando}
              />
              <Grid item xs={12} textAlign="right">
                <Button variant="contained" type="submit">
                  {editando ? "Actualizar" : "Guardar"}
                </Button>
              </Grid>
            </Grid>
          </FormContainer>
        </DialogContent>
      </Dialog>

      <ConfirmDialog
        open={confirmarEliminar}
        title="¿Eliminar país?"
        message="Esta acción no se puede deshacer. ¿Estás seguro de eliminar este país?"
        icon={<DeleteIcon color="error" />}
        confirmColor="error"
        confirmText="Eliminar"
        cancelText="Cancelar"
        onClose={() => setConfirmarEliminar(false)}
        onConfirm={handleEliminar}
      />

      <CustomSnackbar
        open={open}
        onClose={closeSnackbar}
        message={message}
        severity={severity}
      />
    </Container>
  );
}

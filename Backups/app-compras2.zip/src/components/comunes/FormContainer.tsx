import { Box, Paper } from "@mui/material";
import { ReactNode } from "react";

interface Props {
  children: ReactNode;
  padding?: number;
  shadow?: number;
  spacing?: number;
}

export default function FormContainer({
  children,
  padding = 3,
  shadow = 1,
}: Props) {
  return (
    <Paper elevation={shadow} sx={{ p: padding, mb: 4, backgroundColor: "#fff" }}>
      <Box component="form">{children}</Box>
    </Paper>
  );
}

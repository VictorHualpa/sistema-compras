import { DataGrid, GridColDef, GridPaginationModel } from "@mui/x-data-grid";
import { Paper, Box } from "@mui/material";
import { useState } from "react";

interface Props {
  rows: any[];
  columns: GridColDef[];
  getRowId: (row: any) => string;
  pageSizeOptions?: number[];
  height?: string | number;
}

export default function CustomDataGrid({
  rows,
  columns,
  getRowId,
  pageSizeOptions = [5, 10, 20],
  height = "auto",
}: Props) {
  const [paginationModel, setPaginationModel] = useState<GridPaginationModel>({
    page: 0,
    pageSize: pageSizeOptions[0],
  });

  return (
    <Paper elevation={2}>
      <Box sx={{ width: "100%", p: 2, height }}>
        <DataGrid
          rows={rows}
          columns={columns}
          getRowId={getRowId}
          paginationModel={paginationModel}
          onPaginationModelChange={setPaginationModel}
          pageSizeOptions={pageSizeOptions}
          autoHeight
          disableRowSelectionOnClick
        />
      </Box>
    </Paper>
  );
}

import { Pais } from "../components/Pais/pais.types";

const API_URL = "http://192.168.39.137:5000/api/pais";

const headers = () => ({
  Authorization: `Bearer ${localStorage.getItem("token")}`,
  "Content-Type": "application/json",
});

export const obtenerPaises = async (): Promise<Pais[]> => {
  const res = await fetch(API_URL, { headers: headers() });
  return res.json();
};

export const crearPais = async (pais: Pais) => {
  const res = await fetch(API_URL, {
    method: "POST",
    headers: headers(),
    body: JSON.stringify(pais),
  });
  return res.json();
};

export const actualizarPais = async (id: string, pais: Pais) => {
  const res = await fetch(`${API_URL}/${id}`, {
    method: "PUT",
    headers: headers(),
    body: JSON.stringify(pais),
  });
  return res.json();
};

export const eliminarPais = async (id: string) => {
  await fetch(`${API_URL}/${id}`, {
    method: "DELETE",
    headers: headers(),
  });
};
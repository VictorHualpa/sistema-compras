export interface Unidad {
    cod_unidad: string;
    dsc_unidad: string;
    pso_refenc: string;
    cnt_bultos: string;
    flg_replica: string;
    cod_usuario_c: string;
    fch_crea: string | null;
    cod_usuario_m: string;
    fch_mod: string | null;
  }